from django.contrib import admin
from django.urls import path, include
from .views import home, cadastro, salvar
urlpatterns = [
    path('', home),
    path('pagamento', cadastro),
    path('salvar', salvar, name = "salvar")
]