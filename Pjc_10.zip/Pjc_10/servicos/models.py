from django.db import models

# Create your models here.

class Carteira(models.Model):
    codigo = models.CharField(max_length=3)
    produto = models.CharField(max_length=50)
    data = models.CharField(max_length=10)
    preco = models.CharField(max_length=25)
    def __str__(self):
        return self.codigo
    def __str__(self):
        return self.produto
    def __str__(self):
        return self.data
    def __str__(self):
        return self.preco
