from django.shortcuts import redirect, render
from .models import Carteira

# Create your views here.

def home(request):
    carteira = Carteira.objects.all()
    return render(request, "index.html", {"carteirinha":carteira})

def cadastro(request):
    return render(request, "pagamento.html")

def salvar(request):
    vcodigo = request.POST.get("codigo")
    vproduto = request.POST.get("produto")
    vdata = request.POST.get("data")
    vpreco = request.POST.get("preco")
    Carteira.objects.create(codigo = vcodigo, produto = vproduto, data = vdata, preco = vpreco)
    carteirinha = Carteira.objects.all()
    return redirect(home)
    